chrome.runtime.onInstalled.addListener(() => {
    console.log("Wikipedia DALLE Image Replacer installed.");
  });
  