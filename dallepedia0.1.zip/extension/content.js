// Helper function to get image description (placeholder - implement based on Wikipedia's structure)
function getImageDescription(imgElement) {
  const figureParent = imgElement.closest('figure');
  const figcaption = figureParent ? figureParent.querySelector('figcaption') : null;
  return figcaption ? figcaption.innerText : '';
}
// Function to create and attach a toggle button to each image
function attachToggleButton(imgElement) {
  let toggleButton = document.createElement('button');
  toggleButton.textContent = 'Toggle Image';
  toggleButton.style.position = 'absolute';
  toggleButton.style.zIndex = 1000;
  toggleButton.onclick = () => toggleImageDisplay(imgElement);
  imgElement.parentNode.insertBefore(toggleButton, imgElement.nextSibling);
}

// Function to switch between original and DALLE-generated images
function toggleImageDisplay(imgElement) {
  const originalSrc = imgElement.getAttribute('data-original-src');
  const dalleSrc = imgElement.getAttribute('data-dalle-src');

  if (imgElement.src === originalSrc) {
      imgElement.src = dalleSrc;
  } else {
      imgElement.src = originalSrc;
  }
}
async function requestImageGeneration(originalSrc, articleTitle, imgDescription, openAIKey) {
  try {
      const response = await fetch('https://vczjzkkqagcuvvqqvweq.supabase.co/functions/v1/dallepedia-server/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ originalImageUrl: originalSrc, articleTitle: articleTitle, imgDescription: imgDescription, openAIKey: openAIKey })
      });
      const data = await response.json();
      return data.dalleImageUrl;
  } catch (error) {
      console.error('Error generating image:', error);
  }
}

// Function to retrieve existing DALLE image URL from the server
async function getExistingDalleImageUrl(originalSrc) {
  try {
      const response = await fetch(`https://vczjzkkqagcuvvqqvweq.supabase.co/functions/v1/dallepedia-server/get-image?originalImageUrl=${encodeURIComponent(originalSrc)}`);
      const data = await response.json();
      return data.dalleImageUrl;
  } catch (error) {
      console.error('Error retrieving image:', error);
  }
}
async function fetchDalleImageUrl(originalSrc, articleTitle, imgDescription) {
  try {
      const response = await fetch('https://vczjzkkqagcuvvqqvweq.supabase.co/functions/v1/dallepedia-server/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: articleTitle, description: imgDescription })
      });
      const data = await response.json();
      return data.dalleImageUrl;
  } catch (error) {
      console.error('Error fetching DALLE image:', error);
      return originalSrc; // Fallback to original image on error
  }
}

function createLoadingIndicator() {
  const loader = document.createElement('div');
  loader.textContent = 'Loading...'; // Replace with a proper loader element or animation
  loader.style.position = 'absolute';
  loader.style.zIndex = 1000;
  return loader;
}

async function processImage(imgElement, articleTitle) {
  const originalSrc = imgElement.src;
  imgElement.setAttribute('data-original-src', originalSrc);
  imgElement.onmouseover = () => imgElement.src = originalSrc;
  imgElement.onmouseout = () => imgElement.src = imgElement.getAttribute('data-dalle-src') || originalSrc;

  const loader = createLoadingIndicator();
  imgElement.parentNode.appendChild(loader);

  const imgDescription = getImageDescription(imgElement);

  chrome.storage.local.get('dalleApiKey', async (data) => {
    if (data.dalleApiKey) {
      const dalleImageUrl = await requestImageGeneration(originalSrc, articleTitle, imgDescription, data.dalleApiKey);
      imgElement.setAttribute('data-dalle-src', dalleImageUrl || originalSrc);
    } else {
      console.error('OpenAI API key is not set.');
    }
    loader.remove();
    attachToggleButton(imgElement);
  });
}

function init() {
  const articleTitle = document.querySelector('h1').innerText;
  const images = document.querySelectorAll('figure.mw-default-size img.mw-file-element'); 
  images.forEach(imgElement => {
      processImage(imgElement, articleTitle);
  });
}

document.addEventListener('DOMContentLoaded', init);
